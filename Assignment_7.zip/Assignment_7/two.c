#include <stdio.h>
extern int showFlags();
int main(){
	int flag = showFlags();
	printf("%d\n",flag);
	for(int i=0; i<32; i++){
		printf("%d ",flag%2);
		flag >>= 1;
	}
	printf("\n");
	return 0;
}